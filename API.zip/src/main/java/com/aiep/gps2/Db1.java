package com.aiep.gps2;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

public class Db1 extends AppCompatActivity {
    //Definicion de objetos para referencia de la activity
    private EditText m,d;
    private TextView v,c1,c2;
    private Button btncalcular,btnmenu;
    boolean valido=false;
    Double costo;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_db1);
        m=(EditText)findViewById(R.id.txtMonto);
        d=(EditText)findViewById(R.id.txtDistancia);

        btncalcular=(Button)findViewById(R.id.btnCalcular);
        btnmenu=(Button)findViewById(R.id.btnMenu);

        v=(TextView)findViewById(R.id.lbValida);
        c1=(TextView)findViewById(R.id.lbCosto1);
        c2=(TextView)findViewById(R.id.lbCosto2);

        btncalcular.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                Double compra,distancia;
                compra=Double.parseDouble(m.getText().toString());
                distancia=Double.parseDouble(d.getText().toString());

                valido=compra>=50000 || distancia <=20; // Asignación de variable booleana valido si la compra es mayor a los 50.000 o la distancia menora o igual a los 20 km.

                costo=0.0;  // Asignación de variable costo como "int" con valor 0.

                if (compra<50000 && distancia<=20)   // Evaluación de condición si la compra es menor a los 50.000 y la distancia mayor o igual a los 20 km.
                {
                    if (compra>=25000 && compra<=49999) { // Evaluación de condición si la compra es mayor a los 25.000 y menor a los 49.999.
                        costo=150*distancia;      // Asignación de variable costo como distancia x $150.
                    } else if (compra<25000) { // Evaluación de condición si la compra es menor a los 25.000.
                        costo=300*distancia;  // Asignación de variable costo como distancia x $300.
                    }
                }
                else if (compra>=50000){     // Evaluación de condición si la compra es mayor a los 50.000.
                    if (distancia>20) { // Evaluación de condición si la distancia es mayor a los 20 km.
                        costo=150*(distancia-20);  // Asignación de variable costo como (distancia - 20 km) x $150.
                    }
                }

                //System.out.println("El monto total de la compra es: $"+compra);
                //System.out.println("La distancia de despacho es: "+distancia+" km");

                if (valido == true) {	   // Evaluación de condición si la compra es válida
                   // System.out.println("**********************"); // Impresión de línea de asteriscos y dejar cursos en próxima línea.
                   // System.out.println("La compra es valida.");   // Impresión  con mensaje de compra válida y dejar cursos en próxima línea.
                   //  System.out.println("**********************");// Impresión de línea de asteriscos y dejar cursos en próxima línea.
                   // System.out.println("El costo de despacho es: $"+costo); // Impresión de costo de despacho y dejar cursos en próxima línea.
                    double total=compra+costo; // Asignación de variable "int" total como la suma de compra más el costo de despacho.
                   // System.out.println("El costo total de la compra mas el despacho es: $"+total); // Impresión de costo total y dejar cursos en próxima línea.

                    v.setText(String.valueOf(valido));
                    c1.setText(String.valueOf(costo));
                    c2.setText(String.valueOf(total));

                }
                else    // Si la compra no es válida
                {
                    v.setText(String.valueOf(valido));
                 //   System.out.println("**********************");// Impresión de línea de asteriscos y dejar cursos en próxima línea.
                 //   System.out.println("La compra no es valida, porque el monto es inferior a $50.000 y excede distancia maxima de despacho de 20 km."); // Impresión con mensaje de compra no válida y dejar cursos en próxima línea.
                 //   System.out.println("**********************");// Impresión de línea de asteriscos y dejar cursos en próxima línea.
                }

            }
        });
        btnmenu.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(Db1.this, subMenu.class));
            }
        });

    }

}