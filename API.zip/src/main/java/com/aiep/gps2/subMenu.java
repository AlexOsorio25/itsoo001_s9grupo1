package com.aiep.gps2;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

import androidx.appcompat.app.AppCompatActivity;

public class subMenu extends AppCompatActivity {
    //Definicion de objetos para referencia de la activity
    private Button btndb,btngps;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_submenu);


        btndb=(Button)findViewById(R.id.btnCalcular);
        btngps=(Button)findViewById(R.id.btnMenu);

        btndb.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(subMenu.this, Db1.class));
            }
        });
        btngps.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(subMenu.this, MapsActivity.class));
            }
        });

    }

}